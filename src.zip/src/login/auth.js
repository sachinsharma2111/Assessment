import { createContext,useState } from "react";
import { useNavigate, Link, Navigate } from "react-router-dom";

const validUserContext = createContext({
    isLogin: false,
    apiAuthCheck: (enteredEmail, enteredPassword) => {},
    localAuthCheck: ()=>{},
});

export const ValidUserProvider = (props) => {
    const [isLoggedIn, setIsLoggedIn] = useState(false);

    async function apiAuthCheck(enteredEmail,enteredPassword){
        const url="https://react-getting-started-default-rtdb.firebaseio.com/seemsneat.json";
        const loginstaus = false;

        await fetch(url)
        .then(response => {
            return response.json();
        })
        .then(data =>{
            const validUsers = [];
            console.log(data);
            for(const key in data) {
                const validUser = {
                    id: key,
                    ...data[key],
                };
                validUsers.push(validUser);
            };
            console.log(validUsers);

            const authUser = validUsers.find(user =>
                user.username === enteredEmail && user.password ===enteredPassword
                );
        
            if(authUser !== undefined){
                localStorage.setItem("loggedInUser", JSON.stringify(authUser));
                setIsLoggedIn(authUser);
            
            }
            else{
                alert('Authentication Failed')
            }
        })
        .catch(e => {
            alert("Server ERROR")
        });
    }
    const localAuthCheckHandler = () =>{
        const localData = JSON.parse(localStorage.getItem("loggedInUser"));
        if(localData !== null){
            setIsLoggedIn(true);
        }
        else{
            setIsLoggedIn(false);
        }
    };

    const context ={
        isLoggedIn: isLoggedIn,
        apiAuthCheck: localAuthCheckHandler,
    }
    return(
        <validUserContext.Provider value={context}>
            {props.children}
        </validUserContext.Provider>
    );
};
export default validUserContext;