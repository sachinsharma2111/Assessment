import React from 'react';
import './Login.css';
import { Navigate, useNavigate } from 'react-router-dom';
import { useRef, useContext, useEffect } from 'react';
import ValidUserContext from "./auth";
import classes from './LoginForm.module.scss';
import { button } from 'bootstrap';
import { FaUserAlt } from 'react-icons/fa';
import { MdPassword } from 'react-icons/md';

let isInitial = true;

function LoginForm() {
  const validUserContext = useContext(ValidUserContext);
  const Navigate = useNavigate();

  useEffect(() => {
    if (isInitial) {
      validUserContext.localAuthCheck();
      isInitial = false;
    }
    validUserContext.isInitial ? Navigate('/Dashboard') : Navigate('/login')
  }, [validUserContext]);

  const emailInputRef = useRef();
  const passwordInputRef = useRef();

  const submitHandler = (event) => {
    event.preventDefault();
    validUserContext.apiAuthCheck(emailInputRef.current.value, passwordInputRef.current.value);
  }
  return (
    <div className={classes.body}>
      <form onSubmit={submitHandler} className={classes.form}>
        <h1>Login</h1>
        <div className={classes.loginpage}>
          <div className={classes.icons} ><FaUserAlt /></div>
          <input
            className={classes.input}
            type="email"
            id='usename'
            name='usename'
            htmlfor='usename'
            autoComplete='on'
            ref={emailInputRef}
            required={validUserContext.isLoggedIn}
          ></input>
        </div>
        <div>
        <div className={classes.icons} ><MdPassword /></div>
          <input
            className={classes.input}
            type="password"
            id='password'
            name='password'
            htmlfor='password'
            autoComplete='on'
            ref={passwordInputRef}
            required={validUserContext.isLoggedin}
          ></input>
        </div>
        <button className={classes.form.button}>submit</button>
      </form>
    </div>
  )
}
export default LoginForm;