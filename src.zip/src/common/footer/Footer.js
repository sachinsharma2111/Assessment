import React from "react"
import "./style.css"

const Footer = () => {
  return (
    <>
      <footer>
        <div className='container grid2'>
          <div className='box'>
            <h1>ProKart</h1>
            <p>ProKart is a Sub-Brand of <br /><h3>Prolifics Private Limited</h3></p>

          </div>

          <div className='box'>
            <h2>About Us</h2>
            <ul>
              <li>Careers</li>
              <li>Our Stores</li>
              <li>Our Cares</li>
              <li>Terms & Conditions</li>
              <li>Privacy Policy</li>
            </ul>
          </div>
          <div className='box'>
            <h2>Customer Care</h2>
            <ul>
              <li>Help Center </li>
              <li>How to Buy </li>
              <li>Track Your Order </li>
              <li>Corporate & Bulk Purchasing </li>
              <li>Returns & Refunds </li>
            </ul>
          </div>
          <div className='box'>
            <h2>Contact Us</h2>
            <ul>
              <li>14th Floor, Building No. 12B MindSpace SEZ. K. Raheja IT Park Pvt. Ltd. Hitech City
                Hyderabad Telangana , 500081</li>
              <li>Email: help@ProKart.com</li>
              <li>Phone:  040 39991999 </li>
            </ul>
          </div>
        </div>
      </footer>
    </>
  )
}

export default Footer
