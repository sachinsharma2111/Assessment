import { width } from "@mui/system"
import React from "react"

const Catg = () => {
  
  const data = [
    {
      cateImg: "./images/brands/apple.png",
      cateName: "Apple",
    },
    {
      cateImg: "./images/brands/samsung.png",
      cateName: "Samasung",
    },
    {
      cateImg: "./images/brands/Oppo.png",
      cateName: "Oppo",
    },
    {
      cateImg: "./images/brands/Vivo.png",
      cateName: "Vivo",
    },
    {
      cateImg: "./images/brands/OnePlus.png",
      cateName: "Oneplus",
    },
    {
      cateImg: "./images/brands/sony.png",
      cateName: "Sony",
    },
  ]
  return (
    <>
      <div className='category'>
        <div className='chead d_flex'>
          <h1>Brands </h1>
          <h1>Shops </h1>
        </div>
        {data.map((value, index) => {
          return (
            <div className='box f_flex' key={index}>
              <img style={{width: "35px", marginTop: "-5px"}} src={value.cateImg} alt='' />
              <span>{value.cateName}</span>
            </div>
          )
        })}
        <div className='box box2'>
          <button>View All Brands</button>
        </div>
      </div>
    </>
  )
}

export default Catg
