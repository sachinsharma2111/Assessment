const Data = {
  productItems: [
    {
      id: 1,
      discount: 50,
      cover: "./images/flash/flash-1.png",
      name: "Shoes",
      price: 2999,
    },
    {
      id: 2,
      discount: 40,
      cover: "./images/flash/flash-2.png",
      name: "Watch",
      price: 1599,
    },
    {
      id: 3,
      discount: 40,
      cover: "./images/flash/flash-3.png",
      name: "Lava Mobile Black",
      price: 4999,
    },
    {
      id: 4,
      discount: 40,
      cover: "./images/flash/flash-4.png",
      name: "FireBoult Watch",
      price: 1750,
    },
    {
      id: 5,
      discount: 50,
      cover: "./images/flash/flash-1.png",
      name: "Bata Shoes",
      price: 1300,
    },
    {
      id: 6,
      discount: 50,
      cover: "./images/flash/flash-3.png",
      name: "RadChief Shoes",
      price: 5600,
    },
  ],
}
export default Data
